import { useEffect, useRef, useState } from "react";
import {
  DECK_STATS,
  INSIDE_FEATURES,
  MORNING_STEPS,
  PRODUCT,
  SAMPLE_CARDS,
  formatAUD,
} from "./data";
import { BrandLockup } from "./components/Logo";
import { CardBack, CardBlank, CardFront, FlipCard } from "./components/cards";
import { BagIcon, FeatureIcon, PulseLine } from "./components/icons";
import { MorningPhoto } from "./components/MorningPhoto";
import { BagDrawer } from "./components/BagDrawer";


const NAV_LINKS: [string, string][] = [
  ["The Deck", "#deck"],
  ["The Cards", "#cards"],
  ["The Morning", "#morning"],
  ["What’s Inside", "#inside"],
];

const FAN_ANGLES = [-34, -26, -18, -10, 10, 18, 26, 34];

export default function App() {
  const [qty, setQty] = useState(0);
  const [bagOpen, setBagOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [toast, setToast] = useState(false);
  const toastTimer = useRef<number | undefined>(undefined);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => () => window.clearTimeout(toastTimer.current), []);

  const addToBag = () => {
    setQty((q) => Math.min(10, q + 1));
    setToast(true);
    window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(false), 2200);
  };

  return (
    <div id="top" className="min-h-screen bg-cream font-body text-ink">
      {/* ─── Fixed header ─── */}
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
          scrolled
            ? "bg-cream/90 py-2.5 shadow-[0_1px_0_rgba(33,33,33,0.08)] backdrop-blur-xl"
            : "py-4"
        }`}
      >
        <div className="mx-auto flex w-full max-w-7xl items-center gap-3 px-4">
          <a href="#top" className="flex shrink-0 items-center" aria-label="The Salon Dr. — back to top">
            <BrandLockup tone="dark" />
          </a>
          <nav className="ml-auto hidden items-center gap-x-5 md:flex">
            {NAV_LINKS.map(([label, href]) => (
              <a
                key={href}
                href={href}
                className="whitespace-nowrap text-[13px] font-medium text-ink/70 transition hover:text-rose-deep"
              >
                {label}
              </a>
            ))}
          </nav>
          <div className="ml-auto flex shrink-0 items-center gap-2 md:ml-3">
            <button
              onClick={() => setBagOpen(true)}
              aria-label={`Bag, ${qty} items`}
              className="relative grid h-11 w-11 place-items-center rounded-full border border-ink/15 bg-white/80 transition hover:border-rose"
            >
              <BagIcon />
              {qty > 0 && (
                <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-rose px-1 text-[10px] font-semibold text-white">
                  {qty}
                </span>
              )}
            </button>
            <button
              onClick={addToBag}
              className="hidden rounded-full bg-rose-deep px-5 py-2.5 font-display text-xs font-semibold uppercase tracking-[0.15em] text-cream transition hover:bg-ink sm:inline-flex"
            >
              Add to bag
            </button>
          </div>
        </div>
      </header>

      {toast && (
        <div className="animate-toast-in fixed left-1/2 top-20 z-[70] -translate-x-1/2 rounded-full bg-ink px-5 py-2.5 text-sm font-medium text-cream shadow-xl">
          ✓ Added to bag
        </div>
      )}

      {/* ─── Hero ─── */}
      <section id="deck" className="relative overflow-hidden pb-20 pt-32 md:pt-40">
        <div className="pointer-events-none absolute -left-32 top-80 h-96 w-96 rounded-full bg-sand/60 blur-3xl" />
        <div className="pointer-events-none absolute -right-32 -top-40 h-[28rem] w-[28rem] rounded-full bg-blush/40 blur-3xl" />
        <div className="relative mx-auto grid w-full max-w-7xl items-center gap-12 px-4 lg:grid-cols-2">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full border border-rose/40 bg-white/70 px-4 py-1.5 font-display text-[10px] font-semibold uppercase tracking-[0.2em] text-rose-deep backdrop-blur">
              <span className="h-1.5 w-1.5 rounded-full bg-rose" /> No more guessing. Confidence
              waiting.
            </span>
            <h1 className="mt-6 font-display text-4xl font-semibold leading-[1.1] tracking-tight sm:text-5xl lg:text-6xl">
              30 days to
              <br />
              <span className="text-rose-deep">retail confidence.</span>
            </h1>
            <p className="mt-6 max-w-lg text-lg leading-relaxed text-ink/70">{PRODUCT.blurb}</p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <button
                onClick={addToBag}
                className="rounded-full bg-rose-deep px-8 py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-cream shadow-lg shadow-rose/30 transition hover:bg-ink"
              >
                Add to bag
              </button>
              <a
                href="#cards"
                className="rounded-full border border-ink/20 bg-white/70 px-7 py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-ink backdrop-blur transition hover:border-rose"
              >
                Turn the cards →
              </a>
            </div>
            <p className="mt-5 text-xs text-ink/50">
              Complimentary shipping across Australia · One deck runs the whole team’s huddle
            </p>
          </div>

          {/* Fanned deck */}
          <div className="relative pb-10">
            <div className="relative mx-auto aspect-[4/5] w-full max-w-md">
              <div className="pointer-events-none absolute inset-8 rounded-full bg-blush/40 blur-3xl" />
              {FAN_ANGLES.map((angle) => (
                <div
                  key={angle}
                  className="absolute left-1/2 top-1/2 w-[52%] shadow-xl shadow-rose-deep/20"
                  style={{
                    transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(${
                      -4 - Math.abs(angle) * 0.05
                    }%)`,
                    zIndex: 1,
                  }}
                >
                  <CardBlank />
                </div>
              ))}
              <div
                className="absolute left-1/2 top-1/2 w-[54%] shadow-2xl shadow-rose-deep/30"
                style={{ transform: "translate(-50%, -50%) rotate(-3deg)", zIndex: 3 }}
              >
                <CardFront quote={SAMPLE_CARDS[0].quote} />
              </div>
            </div>
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 rounded-2xl border border-sand bg-white px-5 py-3 text-center shadow-xl">
              <p className="font-display text-xs font-semibold uppercase tracking-[0.15em] text-rose-deep">
                {PRODUCT.name}
              </p>
              <p className="mt-0.5 text-xs text-ink/50">{PRODUCT.tagline}</p>
            </div>
          </div>
        </div>
      </section>

      {/* ─── Trust strip ─── */}
      <section className="border-y border-sand bg-white/60">
        <div className="mx-auto grid max-w-5xl gap-4 px-4 py-6 text-center sm:grid-cols-3">
          {["✓ Free shipping in Australia", "✓ Arrives in 5–8 days", "✓ One deck, whole team"].map(
            (line) => (
              <p
                key={line}
                className="font-display text-xs font-semibold uppercase tracking-[0.15em] text-ink/70"
              >
                {line}
              </p>
            )
          )}
        </div>
      </section>

      {/* ─── Manifesto ─── */}
      <section className="mx-auto max-w-3xl px-4 py-20 text-center">
        <PulseLine />
        <h2 className="mt-6 font-display text-3xl font-semibold leading-snug sm:text-4xl">
          Most retail training evaporates by Wednesday.{" "}
          <span className="text-rose-deep">This deck doesn’t let it.</span>
        </h2>
        <p className="mt-6 text-lg leading-relaxed text-ink/60">
          Training day starts the habit. This deck is what keeps it alive at 8:45 every morning —
          with or without Sonia in the room.
        </p>
      </section>

      {/* ─── Sample cards ─── */}
      <section id="cards" className="scroll-mt-16 bg-gradient-to-b from-cream to-sand/40 py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <span className="font-display text-[10px] font-semibold uppercase tracking-[0.25em] text-rose-deep">
              Sample the ritual
            </span>
            <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl">
              Three cards from the deck. Turn them over.
            </h2>
            <p className="mt-4 leading-relaxed text-ink/60">
              This is a taste, not the whole 30 days. The front names the ritual. The back is what
              your team actually says out loud. Tap any card.
            </p>
          </div>
          <div className="mx-auto mt-12 grid max-w-4xl gap-8 sm:grid-cols-3">
            {SAMPLE_CARDS.map((card) => (
              <FlipCard key={card.id} name={card.name} quote={card.quote} back={card.back} />
            ))}
          </div>
        </div>
      </section>

      {/* ─── How the morning runs ─── */}
      <section id="morning" className="scroll-mt-16 py-20">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-4 lg:grid-cols-2">
          <div className="order-1">
            <MorningPhoto
              fallback={
                <div className="bg-gradient-to-br from-sand via-blush to-rose p-8 sm:p-12">
                  <div className="relative mx-auto aspect-[3/4] w-full max-w-xs">
                    <div
                      className="absolute left-1/2 top-1/2 w-[80%] shadow-2xl shadow-rose-deep/30"
                      style={{ transform: "translate(-50%, -50%) rotate(-4deg)" }}
                    >
                      <div className="text-[clamp(11px,2.6vw,18px)]">
                        <CardBack sections={SAMPLE_CARDS[1].back} />
                      </div>
                    </div>
                    <div
                      className="absolute left-[58%] top-[62%] w-[38%] shadow-xl shadow-rose-deep/25"
                      style={{ transform: "translate(-50%, -50%) rotate(9deg)", zIndex: 2 }}
                    >
                      <CardBlank />
                    </div>
                  </div>
                </div>
              }
            />
          </div>
          <div className="order-2">
            <span className="font-display text-[10px] font-semibold uppercase tracking-[0.25em] text-rose-deep">
              The Daily Huddle
            </span>
            <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl">
              How the morning runs.
            </h2>
            <p className="mt-4 leading-relaxed text-ink/60">
              Five minutes. No slides. The deck does the facilitating.
            </p>
            <ol className="mt-8 space-y-6">
              {MORNING_STEPS.map((step) => (
                <li key={step.time} className="flex gap-5">
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-sand font-display text-xs font-semibold text-rose-deep">
                    {step.time}
                  </span>
                  <div>
                    <h3 className="font-display font-semibold">{step.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-ink/60">{step.text}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      {/* ─── What's inside ─── */}
      <section id="inside" className="scroll-mt-16 bg-white/60 py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mx-auto max-w-2xl text-center">
            <span className="font-display text-[10px] font-semibold uppercase tracking-[0.25em] text-rose-deep">
              In the box
            </span>
            <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl">
              What’s inside the deck.
            </h2>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
              {DECK_STATS.map((stat) => (
                <div key={stat.label} className="flex items-baseline gap-2.5">
                  <span className="font-display text-3xl font-semibold text-rose-deep">
                    {stat.count}
                  </span>
                  <span className="text-sm text-ink/70">{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {INSIDE_FEATURES.map((feature) => (
              <div
                key={feature.title}
                className="rounded-3xl border border-sand bg-cream p-7 transition hover:-translate-y-1 hover:shadow-xl hover:shadow-rose/15"
              >
                <FeatureIcon name={feature.icon} />
                <h3 className="mt-4 font-display font-semibold">{feature.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink/60">{feature.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Closing CTA ─── */}
      <section className="pb-24 pt-20">
        <div className="mx-auto max-w-3xl px-4 text-center">
          <PulseLine />
          <h2 className="mt-6 font-display text-3xl font-semibold sm:text-4xl">
            8:45 tomorrow morning could sound different.
          </h2>
          <p className="mx-auto mt-5 max-w-xl leading-relaxed text-ink/60">
            One deck. {formatAUD(PRODUCT.price)}. Free shipping anywhere in Australia. Put it on the
            back bar the morning it lands, and let the cards run the huddle.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={addToBag}
              className="rounded-full bg-rose-deep px-9 py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-cream shadow-lg shadow-rose/30 transition hover:bg-ink"
            >
              Add to bag
            </button>
            <button
              onClick={() => setBagOpen(true)}
              className="rounded-full border border-ink/20 px-8 py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-ink transition hover:border-rose"
            >
              View bag {qty > 0 ? `(${qty})` : ""}
            </button>
          </div>
          <p className="mt-5 text-xs text-ink/40">
            You’ll be contacted to confirm payment and delivery. No card is charged on this page.
          </p>
        </div>
      </section>

      {/* ─── Footer ─── */}
      <footer className="border-t border-sand bg-white/60">
        <div className="mx-auto flex max-w-7xl flex-col items-center gap-6 px-4 py-10 text-center md:flex-row md:justify-between md:text-left">
          <a href="#top" className="flex shrink-0 items-center" aria-label="The Salon Dr. — back to top">
            <BrandLockup tone="dark" showTagline />
          </a>
          <p className="max-w-md text-xs leading-relaxed text-ink/50">
            {PRODUCT.name} — {PRODUCT.tagline} In-salon sales &amp; retail training, Australia-wide.
          </p>
        </div>
        <div className="border-t border-sand/70 py-4 text-center text-[11px] text-ink/40">
          © {new Date().getFullYear()} The Salon Dr. · All rights reserved
        </div>
      </footer>

      <BagDrawer open={bagOpen} qty={qty} onClose={() => setBagOpen(false)} onSetQty={setQty} />
    </div>
  );
}