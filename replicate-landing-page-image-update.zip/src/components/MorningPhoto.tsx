import { useEffect, useRef, useState } from "react";
import type { ChangeEvent, ReactNode } from "react";
import morningPhoto from "../assets/morning-photo.jpg";

const STORAGE_KEY = "salon-dr-morning-photo";

function readLocalPhoto(): string {
  try {
    return window.localStorage.getItem(STORAGE_KEY) || "";
  } catch {
    return "";
  }
}

/**
 * "How the morning runs" photograph — the woman holding the rose card deck.
 * The real photo ships in the bundle; ?edit=photo exposes a local swap control.
 */
export function MorningPhoto({ fallback }: { fallback: ReactNode }) {
  const [localPhoto, setLocalPhoto] = useState<string>(readLocalPhoto);
  const [failed, setFailed] = useState(false);
  const [message, setMessage] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const editMode = new URLSearchParams(window.location.search).get("edit") === "photo";
  const src = localPhoto || morningPhoto;

  useEffect(() => {
    setFailed(false);
  }, [src]);

  function onPick(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setMessage("Please select a photograph.");
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => setMessage("Could not read the photo. Please try again.");
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => setMessage("Could not open the photo. Please try a JPG or PNG.");
      img.onload = () => {
        const scale = Math.min(1, 1400 / img.width, 1800 / img.height);
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          setMessage("Could not process the photo in this browser.");
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
        setLocalPhoto(dataUrl);
        setFailed(false);
        try {
          window.localStorage.setItem(STORAGE_KEY, dataUrl);
          setMessage("");
        } catch {
          setMessage("Photo displayed, but this browser could not save it for your next visit.");
        }
      };
      img.src = String(reader.result);
    };
    reader.readAsDataURL(file);
    event.target.value = "";
  }

  function removeLocal() {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      /* private mode */
    }
    setLocalPhoto("");
    setFailed(false);
  }

  return (
    <figure className="relative mx-auto w-full max-w-xl overflow-hidden rounded-[2rem] bg-sand/50 shadow-2xl shadow-rose/20">
      {!failed ? (
        <img
          src={src}
          alt="A woman holding the 30 Days to Retail Confidence card deck"
          className="aspect-[3/4] w-full object-cover object-[center_48%]"
          loading="lazy"
          decoding="async"
          onError={() => setFailed(true)}
        />
      ) : (
        fallback
      )}
      {(editMode || failed) && (
        <figcaption className="border-t border-sand bg-cream px-5 py-5 text-center">
          <input
            ref={inputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={onPick}
            className="sr-only"
            aria-label="Select the woman-with-cards photograph"
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="rounded-full bg-rose-deep px-5 py-2.5 text-xs font-semibold text-cream transition hover:bg-ink"
          >
            {localPhoto ? "Change photo" : "Choose the photo for this section"}
          </button>
          {localPhoto && (
            <button
              type="button"
              onClick={removeLocal}
              className="ml-4 text-xs text-ink/60 underline underline-offset-4"
            >
              Remove local photo
            </button>
          )}
          {message && (
            <p role="alert" className="mt-2 text-xs text-rose-deep">
              {message}
            </p>
          )}
          <p className="mt-2 text-xs leading-relaxed text-ink/60">
            Select the photograph of the woman holding the cards. It will show here on this device.
          </p>
        </figcaption>
      )}
    </figure>
  );
}
