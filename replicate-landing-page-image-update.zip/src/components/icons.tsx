import type { FeatureIconName } from "../data";

/** Hand-drawn style feature icons — rose strokes with gold + blush accents. */
export function FeatureIcon({ name }: { name: FeatureIconName }) {
  const shared = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round",
    strokeLinejoin: "round",
  } as const;
  return (
    <svg
      aria-hidden="true"
      focusable="false"
      viewBox="0 0 48 48"
      className="h-11 w-11 shrink-0 text-rose-deep"
      {...shared}
    >
      {name === "cards" && (
        <>
          <rect x="8.5" y="11" width="24" height="31" rx="4" transform="rotate(-9 8.5 11)" stroke="#cbb26a" />
          <rect x="17" y="9" width="23" height="31" rx="4" fill="#fffafb" />
          <rect x="17" y="9" width="23" height="31" rx="4" />
          <path d="M23 19h11M23 24h11M23 29h7" stroke="#cbb26a" />
          <circle cx="34" cy="34" r="1.4" fill="#e1849f" stroke="none" />
        </>
      )}
      {name === "mindset" && (
        <>
          <path d="M23.8 39.5c-2.2 2-6 1-6.8-2-4.3.6-7.3-3.6-5.7-7.4-3.3-2.3-3-7.3.5-9.2-.7-4.3 3.2-7.5 7-6.4 1.7-3.5 6.7-4.3 9.3-1.4 3.5-2.3 8.4-.1 8.7 4.2 4.3 1.1 5.5 6.1 2.4 9.2 1.7 4.1-1.4 8.3-5.5 8 0 3.7-4.6 6-7.7 3.7" />
          <path
            d="M24 14v25M18.3 19.2c2.7.1 4.3 2.2 4.3 4.6M17.1 29c2.9-.1 4.6 1.5 4.9 4.1M29.7 18.3c-2.2.7-3.1 2.4-3.1 4.5M32.4 27.3c-2.1.3-3.5 1.8-3.5 4.1"
            stroke="#cbb26a"
          />
          <path d="M7.5 10.5v5M5 13h5M40 8v4M38 10h4" stroke="#cbb26a" />
        </>
      )}
      {name === "box" && (
        <>
          <path d="m7 16 17-9 17 9-17 10-17-10Z" stroke="#cbb26a" />
          <path d="M7 16v17l17 9 17-9V16M24 26v16M15.5 11.5l17 10" />
          <path d="M12 19v11l8 4V24l-8-5Z" fill="#ebadbf" stroke="none" />
          <path d="M12 19v11l8 4V24l-8-5Z" stroke="#b4556f" />
          <path d="m29 12 8 4.2" stroke="#cbb26a" />
        </>
      )}
      {name === "repeat" && (
        <>
          <path d="M37.5 17.5A15 15 0 0 0 12 13l-3 3" />
          <path d="M9 10v6h6M10.5 30.5A15 15 0 0 0 36 35l3-3" />
          <path d="M39 38v-6h-6" />
          <path d="M24 17v14M19.5 20.5h9l-1.3-3.5M20.8 31.5l-1.3-3.5h9" stroke="#cbb26a" />
          <circle cx="24" cy="24" r="2.4" fill="#ebadbf" stroke="none" />
        </>
      )}
    </svg>
  );
}

/** The little heartbeat rule that opens the manifesto + closing sections. */
export function PulseLine({ className = "" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 220 28"
      className={`mx-auto h-7 w-auto text-rose ${className}`}
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="M2 14h55l8-10 10 20 8-10h28l7-7 9 14 7-7h78" />
    </svg>
  );
}

export function BagIcon() {
  return (
    <svg
      width="18"
      height="18"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      aria-hidden="true"
    >
      <path d="M6.5 8h11l-.8 12.2a1 1 0 0 1-1 .8H8.3a1 1 0 0 1-1-.8L6.5 8z" />
      <path d="M9 8V6.8A3 3 0 0 1 12 3.8 3 3 0 0 1 15 6.8V8" />
    </svg>
  );
}