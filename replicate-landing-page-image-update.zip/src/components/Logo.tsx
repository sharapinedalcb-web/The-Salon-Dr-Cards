import { useId } from "react";

/** The Salon Dr. gold "prescription kit" mark. */
export function GoldKitMark({ className = "" }: { className?: string }) {
  const id = `sdGold-${useId().replace(/:/g, "")}`;
  return (
    <svg viewBox="0 0 120 120" className={className} fill="none" aria-hidden="true">
      <defs>
        <linearGradient id={id} x1="1" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F8E9A8" />
          <stop offset="45%" stopColor="#D8AD49" />
          <stop offset="100%" stopColor="#A2732A" />
        </linearGradient>
      </defs>
      <rect x="45" y="15" width="30" height="19" rx="6" stroke={`url(#${id})`} strokeWidth="5.5" />
      <rect x="16" y="29" width="88" height="74" rx="10" stroke={`url(#${id})`} strokeWidth="5.5" />
      <rect x="41" y="46" width="38" height="38" rx="6" stroke={`url(#${id})`} strokeWidth="4.5" />
      <path d="M60 53v24M48 65h24" stroke={`url(#${id})`} strokeWidth="4.5" strokeLinecap="round" />
    </svg>
  );
}

export function BrandLockup({
  tone = "dark",
  showTagline = false,
  className = "",
}: {
  tone?: "dark" | "light";
  showTagline?: boolean;
  className?: string;
}) {
  const main = tone === "dark" ? "text-ink" : "text-cream";
  const sub = tone === "dark" ? "text-rose-deep" : "text-blush";
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <GoldKitMark className="h-10 w-10 shrink-0" />
      <span className="flex flex-col leading-none">
        <span
          className={`font-brand text-[15px] tracking-[0.14em] ${main}`}
          style={{ fontWeight: 400 }}
        >
          THE SALON DR.
        </span>
        {showTagline ? (
          <span className={`mt-1.5 font-brand text-[6.5px] leading-none tracking-[0.18em] ${sub}`}>
            TO DIAGNOSE AND PRESCRIBE THE RIGHT SOLUTIONS
          </span>
        ) : (
          <span className={`mt-1.5 font-brand text-[7px] leading-none tracking-[0.22em] ${sub}`}>
            THE SHOP
          </span>
        )}
      </span>
    </span>
  );
}