import { useState } from "react";
import type { CSSProperties } from "react";
import type { CardSection } from "../data";

/** Rose card front — serif prompt, cream signature. Sizes via container queries. */
export function CardFront({
  header = "30 DAYS TO RETAIL CONFIDENCE",
  quote,
  className = "",
}: {
  header?: string;
  quote: string;
  className?: string;
}) {
  return (
    <div
      className={`card-face relative flex aspect-[5/7] w-full flex-col items-center justify-between overflow-hidden rounded-[0.6rem] bg-[#E9899A] px-[8%] py-[9%] ${className}`}
    >
      {header && (
        <p className="w-full text-center font-card text-[4.2cqw] uppercase tracking-[0.14em] text-cream/95">
          {header}
        </p>
      )}
      <p className="w-full text-center font-cardserif text-[9.4cqw] font-normal leading-[1.2] text-cream">
        {quote}
      </p>
      <div className="w-full">
        <div className="mx-auto mb-[6%] h-px w-[62%] bg-cream/80" />
        <p className="text-center font-cardserif text-[5.4cqw] tracking-wide text-cream">
          <span className="mr-[0.4em] inline-block h-px w-[1.4em] translate-y-[-0.28em] bg-cream/70 align-middle" />
          The Salon Dr.
          <span className="ml-[0.4em] inline-block h-px w-[1.4em] translate-y-[-0.28em] bg-cream/70 align-middle" />
        </p>
      </div>
    </div>
  );
}

/** Cream card back — coaching sections split by gold hairlines. */
export function CardBack({
  sections,
  className = "",
}: {
  sections: CardSection[];
  className?: string;
}) {
  return (
    <div
      className={`card-face relative flex aspect-[5/7] w-full flex-col justify-between overflow-hidden rounded-[0.6rem] bg-[#F4F1E6] px-[8%] py-[9%] ${className}`}
    >
      <div className="flex flex-1 flex-col justify-evenly">
        {sections.map((section, i) => (
          <div key={section.heading}>
            {i > 0 && <div className="mx-auto mb-[7%] h-px w-[78%] bg-[#C9A96A]" />}
            <p className="text-center font-cardserif text-[8.4cqw] leading-[1.16] text-[#C25566]">
              {section.heading}
            </p>
            <p className="mx-auto mt-[3.5%] max-w-[94%] text-center font-card text-[6.6cqw] leading-[1.34] text-[#C25566]">
              {section.body}
            </p>
          </div>
        ))}
      </div>
      <p className="mt-[5%] text-center font-cardserif text-[5.4cqw] tracking-wide text-[#C25566]">
        <span className="mr-[0.4em] inline-block h-px w-[1.4em] translate-y-[-0.28em] bg-[#C9A96A] align-middle" />
        The Salon Dr.
        <span className="ml-[0.4em] inline-block h-px w-[1.4em] translate-y-[-0.28em] bg-[#C9A96A] align-middle" />
      </p>
    </div>
  );
}

/** Plain rose card used for the fanned deck in the hero. */
export function CardBlank({
  className = "",
  style,
}: {
  className?: string;
  style?: CSSProperties;
}) {
  return (
    <div
      className={`aspect-[5/7] w-full rounded-[0.6rem] bg-gradient-to-br from-[#EE9AA8] to-[#E58895] ${className}`}
      style={style}
    />
  );
}

/** Tap-to-flip sample card with the "Turn over →" affordance. */
export function FlipCard({
  name,
  quote,
  back,
}: {
  name: string;
  quote: string;
  back: CardSection[];
}) {
  const [flipped, setFlipped] = useState(false);
  return (
    <button
      type="button"
      onClick={() => setFlipped((f) => !f)}
      className="flip-scene group block w-full text-left focus:outline-none"
      aria-label={`${name} card — tap to turn over`}
      aria-pressed={flipped}
    >
      <div className={`flip-inner relative w-full ${flipped ? "flipped" : ""}`}>
        <div className="flip-face relative transition-shadow group-hover:drop-shadow-xl">
          <CardFront quote={quote} />
        </div>
        <div className="flip-face flip-back absolute inset-0">
          <CardBack sections={back} />
        </div>
      </div>
      <span className="mt-4 block text-center font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/40 transition group-hover:text-rose-deep">
        {flipped ? "Turn back over" : "Turn over →"}
      </span>
    </button>
  );
}