import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import { PRODUCT, formatAUD } from "../data";

type Step = "bag" | "checkout" | "done";

interface Order {
  id: string;
  name: string;
  email: string;
}

export function BagDrawer({
  open,
  qty,
  onClose,
  onSetQty,
}: {
  open: boolean;
  qty: number;
  onClose: () => void;
  onSetQty: (updater: (q: number) => number) => void;
}) {
  const [step, setStep] = useState<Step>("bag");
  const [order, setOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
    };
    document.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, step]);

  if (!open) return null;

  const subtotal = qty * PRODUCT.price;

  function close() {
    onClose();
    if (step === "done") {
      onSetQty(() => 0);
      setStep("bag");
    }
  }

  function placeOrder(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    setOrder({
      id: "SD-" + Date.now().toString().slice(-6),
      name: String(data.get("name") || ""),
      email: String(data.get("email") || ""),
    });
    setStep("done");
  }

  return (
    <div className="fixed inset-0 z-[80]" role="dialog" aria-modal="true" aria-label="Shopping bag">
      <div className="animate-scrim-in absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={close} />
      <aside className="animate-drawer-in absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-cream shadow-2xl">
        <header className="flex items-center justify-between border-b border-sand px-6 py-5">
          <h2 className="font-display text-sm font-semibold uppercase tracking-[0.18em] text-ink">
            {step === "bag" ? "Your bag" : step === "checkout" ? "Checkout" : "Order confirmed"}
          </h2>
          <button
            onClick={close}
            aria-label="Close bag"
            className="grid h-9 w-9 place-items-center rounded-full border border-ink/15 text-ink transition hover:border-rose"
          >
            ✕
          </button>
        </header>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          {step === "bag" &&
            (qty === 0 ? (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <span className="text-4xl">👜</span>
                <p className="mt-4 font-display font-semibold text-ink">Your bag is empty.</p>
                <p className="mt-2 text-sm text-ink/60">
                  The deck is the only thing we sell. On purpose.
                </p>
                <a
                  href="#deck"
                  onClick={close}
                  className="mt-6 rounded-full bg-rose-deep px-6 py-3 font-display text-xs font-semibold uppercase tracking-[0.15em] text-cream transition hover:bg-ink"
                >
                  View the deck
                </a>
              </div>
            ) : (
              <>
                <div className="flex gap-4 rounded-2xl border border-sand bg-white p-4">
                  <div className="grid h-20 w-16 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-sand to-blush font-display text-[9px] font-semibold uppercase tracking-widest text-rose-deep">
                    30 Days
                  </div>
                  <div className="min-w-0 flex-1">
                    <h3 className="font-display text-sm font-semibold text-ink">{PRODUCT.name}</h3>
                    <p className="mt-0.5 text-xs text-ink/50">Physical deck · Australia</p>
                    <div className="mt-3 flex items-center justify-between">
                      <div className="flex items-center rounded-full border border-ink/15">
                        <button
                          onClick={() => onSetQty((q) => Math.max(0, q - 1))}
                          aria-label="Decrease quantity"
                          className="grid h-8 w-8 place-items-center rounded-full text-ink transition hover:text-rose-deep"
                        >
                          −
                        </button>
                        <span className="w-6 text-center text-sm font-semibold text-ink">{qty}</span>
                        <button
                          onClick={() => onSetQty((q) => Math.min(10, q + 1))}
                          aria-label="Increase quantity"
                          className="grid h-8 w-8 place-items-center rounded-full text-ink transition hover:text-rose-deep"
                        >
                          +
                        </button>
                      </div>
                      <p className="font-display text-sm font-semibold text-ink">
                        {formatAUD(qty * PRODUCT.price)}
                      </p>
                    </div>
                    <button
                      onClick={() => onSetQty(() => 0)}
                      className="mt-3 text-xs text-ink/40 underline-offset-2 hover:underline"
                    >
                      Remove from bag
                    </button>
                  </div>
                </div>
              </>
            ))}

          {step === "checkout" && (
            <form onSubmit={placeOrder} className="space-y-5">
              <p className="text-xs leading-relaxed text-ink/50">
                Ships Australia-wide. You’ll get a confirmation at the email below.
              </p>
              <div>
                <label
                  htmlFor="order-name"
                  className="font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/60"
                >
                  Full name
                </label>
                <input
                  id="order-name"
                  name="name"
                  required
                  autoComplete="name"
                  placeholder="Sonia Bennett"
                  className="mt-1.5 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm text-ink outline-none transition focus:border-rose"
                />
              </div>
              <div>
                <label
                  htmlFor="order-email"
                  className="font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/60"
                >
                  Email
                </label>
                <input
                  id="order-email"
                  name="email"
                  type="email"
                  required
                  autoComplete="email"
                  placeholder="you@yoursalon.com.au"
                  className="mt-1.5 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm text-ink outline-none transition focus:border-rose"
                />
              </div>
              <div>
                <label
                  htmlFor="order-address"
                  className="font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/60"
                >
                  Salon &amp; delivery address
                </label>
                <textarea
                  id="order-address"
                  name="address"
                  required
                  rows={3}
                  placeholder="Salon name, street, suburb, state, postcode"
                  className="mt-1.5 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm text-ink outline-none transition focus:border-rose"
                />
              </div>
              <div className="flex items-center justify-between rounded-2xl bg-sand/50 px-5 py-4">
                <span className="text-sm text-ink/70">{qty} × deck</span>
                <span className="font-display text-lg font-semibold text-ink">
                  {formatAUD(subtotal)}
                </span>
              </div>
              <button
                type="submit"
                className="w-full rounded-full bg-rose-deep py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-cream transition hover:bg-ink"
              >
                Place order — {formatAUD(subtotal)}
              </button>
              <p className="text-center text-[11px] leading-relaxed text-ink/40">
                You’ll be contacted to confirm payment and delivery. No card is charged on this
                page.
              </p>
              <button
                type="button"
                onClick={() => setStep("bag")}
                className="w-full text-center text-xs text-ink/50 underline-offset-2 hover:underline"
              >
                ← Back to bag
              </button>
            </form>
          )}

          {step === "done" && order && (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <span className="grid h-14 w-14 place-items-center rounded-full bg-rose/20 text-2xl">
                ✓
              </span>
              <h3 className="mt-5 font-display text-xl font-semibold text-ink">
                Your deck is confirmed.
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-ink/60">
                Thanks {order.name.split(" ")[0] || "there"} — order{" "}
                <span className="font-semibold text-ink">{order.id}</span> is on its way to your
                inbox at <span className="font-semibold text-ink">{order.email}</span>.
              </p>
              <p className="mt-3 text-sm leading-relaxed text-ink/60">
                Most decks arrive in 5–8 business days. Put it on the back bar the morning it
                lands.
              </p>
              <button
                onClick={close}
                className="mt-7 rounded-full bg-rose-deep px-7 py-3 font-display text-xs font-semibold uppercase tracking-[0.15em] text-cream transition hover:bg-ink"
              >
                Done
              </button>
            </div>
          )}
        </div>

        {step === "bag" && qty > 0 && (
          <div className="border-t border-sand px-6 py-5">
            <div className="flex items-center justify-between">
              <span className="font-display text-sm font-semibold text-ink">Subtotal</span>
              <span className="font-display text-lg font-semibold text-ink">
                {formatAUD(subtotal)}
              </span>
            </div>
            <p className="mt-1 text-xs text-ink/50">Complimentary shipping across Australia.</p>
            <button
              onClick={() => setStep("checkout")}
              className="mt-4 w-full rounded-full bg-rose-deep py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-cream transition hover:bg-ink"
            >
              Checkout
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}