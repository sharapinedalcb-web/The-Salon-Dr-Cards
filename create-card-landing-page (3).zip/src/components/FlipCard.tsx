import { useState } from 'react';
import { CardFront, CardBack } from './CardFace';

interface Props {
  name: string;
  quote: string;
  back: { heading: string; body: string }[];
}

export default function FlipCard({ name, quote, back }: Props) {
  const [flipped, setFlipped] = useState(false);

  return (
    <button
      onClick={() => setFlipped((f) => !f)}
      className="flip-scene group block w-full text-left focus:outline-none"
      aria-label={`${name} card — tap to turn over`}
    >
      <div className={`flip-inner relative w-full ${flipped ? 'flipped' : ''}`}>
        {/* Front — the card's prompt */}
        <div className="flip-face relative transition-shadow group-hover:drop-shadow-xl">
          <CardFront quote={quote} />
        </div>

        {/* Back — the teaching content */}
        <div className="flip-face flip-back absolute inset-0">
          <CardBack sections={back} />
        </div>
      </div>

      <span className="mt-4 block text-center font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/40 transition group-hover:text-rose-deep">
        {flipped ? 'Turn back over' : 'Turn over →'}
      </span>
    </button>
  );
}
