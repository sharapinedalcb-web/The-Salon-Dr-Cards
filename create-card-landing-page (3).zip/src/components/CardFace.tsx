/**
 * Faithful recreations of the physical 30 Days to Retail Confidence cards.
 * Pink front = the card's prompt. Cream back = the teaching content.
 *
 * All type is sized in `cqw` (container-query width units) so the lettering
 * scales with the card itself — never with the viewport — and stays legible
 * whether the card is 240px or 400px wide.
 */

interface FrontProps {
  header?: string;
  quote: string;
  className?: string;
}

export function CardFront({ header = '30 DAYS TO RETAIL CONFIDENCE', quote, className = '' }: FrontProps) {
  return (
    <div
      className={`card-container relative flex aspect-[5/7] w-full flex-col items-center justify-between overflow-hidden rounded-[0.6rem] bg-[#E9899A] px-[8%] py-[9%] ${className}`}
    >
      {header && (
        <p className="w-full text-center font-card text-[3.5cqw] font-light uppercase leading-tight tracking-[0.14em] text-cream/95">
          {header}
        </p>
      )}

      <p className="w-full text-center font-cardserif text-[9.6cqw] font-normal leading-[1.16] text-cream">
        {quote}
      </p>

      <div className="w-full">
        <div className="mx-auto mb-[5%] h-px w-[62%] bg-cream/80" />
        <p className="text-center font-cardserif text-[4.8cqw] tracking-wide text-cream">
          <span className="mr-[0.4em] inline-block h-px w-[1.4em] translate-y-[-0.28em] bg-cream/70 align-middle" />
          The Salon Dr.
          <span className="ml-[0.4em] inline-block h-px w-[1.4em] translate-y-[-0.28em] bg-cream/70 align-middle" />
        </p>
      </div>
    </div>
  );
}

interface BackSection {
  heading: string;
  body: string;
}

interface BackProps {
  sections: BackSection[];
  className?: string;
}

export function CardBack({ sections, className = '' }: BackProps) {
  const single = sections.length === 1;

  return (
    <div
      className={`card-container relative flex aspect-[5/7] w-full flex-col overflow-hidden rounded-[0.6rem] bg-[#F4F1E6] px-[8%] py-[9%] ${className}`}
    >
      <div className={`flex flex-1 flex-col ${single ? 'justify-center' : 'justify-evenly'}`}>
        {sections.map((s, i) => (
          <div key={s.heading}>
            {i > 0 && <div className="mx-auto mb-[6%] h-px w-[78%] bg-[#C9A96A]" />}

            <p
              className={`text-center font-cardserif leading-[1.15] text-[#D4707F] ${
                single ? 'text-[8.4cqw]' : 'text-[6.4cqw]'
              }`}
            >
              {s.heading}
            </p>

            {single && <div className="mx-auto my-[7%] h-px w-[68%] bg-[#C9A96A]" />}

            <p
              className={`mx-auto text-center font-card font-light leading-[1.4] text-[#D4707F] ${
                single ? 'mt-0 max-w-[88%] text-[5.2cqw]' : 'mt-[3%] max-w-[92%] text-[4.9cqw]'
              }`}
            >
              {s.body}
            </p>
          </div>
        ))}
      </div>

      <p className={`mt-[5%] text-center font-cardserif tracking-wide text-[#D4707F] ${single ? 'text-[4.6cqw]' : 'text-[4.4cqw]'}`}>
        <span className="mr-[0.4em] inline-block h-px w-[1.4em] translate-y-[-0.28em] bg-[#C9A96A] align-middle" />
        The Salon Dr.
        <span className="ml-[0.4em] inline-block h-px w-[1.4em] translate-y-[-0.28em] bg-[#C9A96A] align-middle" />
      </p>
    </div>
  );
}

/** Blank card face — used for the fanned cards behind the front card. */
export function CardBlank({ className = '', style }: { className?: string; style?: React.CSSProperties }) {
  return (
    <div
      className={`aspect-[5/7] w-full rounded-[0.6rem] bg-gradient-to-br from-[#EE9AA8] to-[#E58895] ${className}`}
      style={style}
    />
  );
}
