import { useEffect, useRef, useState, type ChangeEvent, type ReactNode } from 'react';

const STORAGE_KEY = 'salon-dr-morning-photo';

function getSavedPhoto() {
  try {
    return window.localStorage.getItem(STORAGE_KEY) || '';
  } catch {
    return '';
  }
}

type MorningPhotoProps = {
  photoUrl: string;
  fallback: ReactNode;
};

export default function MorningPhoto({ photoUrl, fallback }: MorningPhotoProps) {
  const [savedPhoto, setSavedPhoto] = useState(getSavedPhoto);
  const [availableUrl, setAvailableUrl] = useState('');
  const [failed, setFailed] = useState(false);
  const [error, setError] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const editing = new URLSearchParams(window.location.search).get('edit') === 'photo';
  const photo = savedPhoto || availableUrl;

  // Only render the published image after it loads, so a missing asset never shows a broken image.
  useEffect(() => {
    if (!photoUrl) return;
    const image = new Image();
    image.onload = () => setAvailableUrl(photoUrl);
    image.onerror = () => setAvailableUrl('');
    image.src = photoUrl;
    return () => {
      image.onload = null;
      image.onerror = null;
    };
  }, [photoUrl]);

  function handleFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setError('Please select a photograph.');
      return;
    }

    const reader = new FileReader();
    reader.onerror = () => setError('Could not read the photo. Please try again.');
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => setError('Could not open the photo. Please try a JPG or PNG.');
      image.onload = () => {
        const scale = Math.min(1, 1400 / image.width, 1800 / image.height);
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(image.width * scale);
        canvas.height = Math.round(image.height * scale);
        const context = canvas.getContext('2d');
        if (!context) {
          setError('Could not process the photo in this browser.');
          return;
        }
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setSavedPhoto(dataUrl);
        setFailed(false);
        try {
          window.localStorage.setItem(STORAGE_KEY, dataUrl);
          setError('');
        } catch {
          setError('Photo displayed, but this browser could not save it for your next visit.');
        }
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
    event.target.value = '';
  }

  function removePhoto() {
    try {
      window.localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Browsers can disallow storage; the visible image still resets.
    }
    setSavedPhoto('');
    setFailed(false);
  }

  return (
    <figure className="relative mx-auto w-full max-w-xl overflow-hidden rounded-[2rem] bg-sand/50 shadow-2xl shadow-rose/20">
      {photo && !failed ? (
        <img
          src={photo}
          alt="A woman holding the 30 Days to Retail Confidence card deck"
          className="aspect-[3/4] w-full object-cover object-[center_48%]"
          loading="lazy"
          decoding="async"
          onError={() => setFailed(true)}
        />
      ) : (
        fallback
      )}

      {(editing || !photo || failed) && (
        <figcaption className="border-t border-sand bg-cream px-5 py-5 text-center">
          <input
            ref={inputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            onChange={handleFile}
            className="sr-only"
            aria-label="Select the woman-with-cards photograph"
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="rounded-full bg-rose-deep px-5 py-2.5 text-xs font-semibold text-cream transition hover:bg-ink"
          >
            {savedPhoto ? 'Change photo' : 'Choose the photo for this section'}
          </button>
          {savedPhoto && (
            <button type="button" onClick={removePhoto} className="ml-4 text-xs text-ink/60 underline underline-offset-4">
              Remove local photo
            </button>
          )}
          {error && <p role="alert" className="mt-2 text-xs text-rose-deep">{error}</p>}
          <p className="mt-2 text-xs leading-relaxed text-ink/60">
            Select the photograph of the woman holding the cards. It will show here on this device.
          </p>
        </figcaption>
      )}
    </figure>
  );
}