import { useId } from 'react';

interface MarkProps {
  className?: string;
}

/**
 * The Salon Dr. medical-bag mark.
 * Gold gradient strokes on a fully transparent background.
 */
export function LogoMark({ className = '' }: MarkProps) {
  const uid = useId().replace(/:/g, '');
  const gold = `sdGold-${uid}`;

  return (
    <svg viewBox="0 0 120 120" className={className} fill="none" aria-hidden="true">
      <defs>
        <linearGradient id={gold} x1="1" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#F8E9A8" />
          <stop offset="45%" stopColor="#D8AD49" />
          <stop offset="100%" stopColor="#A2732A" />
        </linearGradient>
      </defs>
      {/* handle */}
      <rect x="45" y="15" width="30" height="19" rx="6" stroke={`url(#${gold})`} strokeWidth="5.5" />
      {/* case */}
      <rect x="16" y="29" width="88" height="74" rx="10" stroke={`url(#${gold})`} strokeWidth="5.5" />
      {/* plaque */}
      <rect x="41" y="46" width="38" height="38" rx="6" stroke={`url(#${gold})`} strokeWidth="4.5" />
      {/* cross */}
      <path d="M60 53v24M48 65h24" stroke={`url(#${gold})`} strokeWidth="4.5" strokeLinecap="round" />
    </svg>
  );
}

interface LogoProps {
  /** 'dark' = for light pages (ink text) · 'light' = for dark pages (cream text) */
  tone?: 'dark' | 'light';
  showTagline?: boolean;
  className?: string;
}

export default function Logo({ tone = 'dark', showTagline = false, className = '' }: LogoProps) {
  const wordColor = tone === 'dark' ? 'text-ink' : 'text-cream';
  const subColor = tone === 'dark' ? 'text-rose-deep' : 'text-blush';

  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <LogoMark className="h-10 w-10 shrink-0" />
      <span className="flex flex-col leading-none">
        <span
          className={`font-brand text-[15px] tracking-[0.14em] ${wordColor}`}
          style={{ fontWeight: 400 }}
        >
          THE SALON DR.
        </span>
        {showTagline ? (
          <span className={`mt-1.5 font-brand text-[6.5px] leading-none tracking-[0.18em] ${subColor}`}>
            TO DIAGNOSE AND PRESCRIBE THE RIGHT SOLUTIONS
          </span>
        ) : (
          <span className={`mt-1.5 font-brand text-[7px] leading-none tracking-[0.22em] ${subColor}`}>
            THE SHOP
          </span>
        )}
      </span>
    </span>
  );
}
