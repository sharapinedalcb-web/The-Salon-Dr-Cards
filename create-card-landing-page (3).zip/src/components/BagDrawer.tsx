import { useState } from 'react';
import { PRODUCT, formatAUD } from '../data/deck';

interface Props {
  open: boolean;
  qty: number;
  onClose: () => void;
  onSetQty: (q: number) => void;
}

type Stage = 'bag' | 'checkout' | 'done';

export default function BagDrawer({ open, qty, onClose, onSetQty }: Props) {
  const [stage, setStage] = useState<Stage>('bag');
  const [order, setOrder] = useState<{ id: string; name: string; email: string } | null>(null);

  if (!open) return null;

  const total = qty * PRODUCT.price;

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    setOrder({
      id: 'SD-' + Date.now().toString().slice(-6),
      name: String(fd.get('name') || ''),
      email: String(fd.get('email') || ''),
    });
    setStage('done');
  };

  const close = () => {
    onClose();
    if (stage === 'done') {
      onSetQty(0);
      setStage('bag');
    }
  };

  return (
    <div className="fixed inset-0 z-[80]">
      <div className="absolute inset-0 bg-ink/40 backdrop-blur-sm" onClick={close} />
      <aside className="absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-cream shadow-2xl">
        <header className="flex items-center justify-between border-b border-sand px-6 py-5">
          <h2 className="font-display text-sm font-semibold uppercase tracking-[0.18em] text-ink">
            {stage === 'bag' ? 'Your bag' : stage === 'checkout' ? 'Checkout' : 'Order confirmed'}
          </h2>
          <button onClick={close} aria-label="Close bag" className="grid h-9 w-9 place-items-center rounded-full border border-ink/15 text-ink transition hover:border-rose">
            ✕
          </button>
        </header>

        <div className="flex-1 overflow-y-auto px-6 py-6">
          {stage === 'bag' && (
            qty === 0 ? (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <span className="text-4xl">👜</span>
                <p className="mt-4 font-display font-semibold text-ink">Your bag is empty.</p>
                <p className="mt-2 text-sm text-ink/60">The deck is the only thing we sell. On purpose.</p>
                <a href="#deck" onClick={close} className="mt-6 rounded-full bg-rose-deep px-6 py-3 font-display text-xs font-semibold uppercase tracking-[0.15em] text-cream transition hover:bg-ink">
                  View the deck
                </a>
              </div>
            ) : (
              <>
                <div className="flex gap-4 rounded-2xl border border-sand bg-white p-4">
                  <div className="grid h-20 w-16 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-sand to-blush font-display text-[9px] font-semibold uppercase tracking-widest text-rose-deep">
                    30 Days
                  </div>
                  <div className="min-w-0">
                    <h3 className="font-display text-sm font-semibold text-ink">{PRODUCT.name}</h3>
                    <p className="mt-0.5 text-xs text-ink/50">Physical deck · Australia</p>
                    <div className="mt-3 flex items-center gap-3">
                      <div className="flex items-center rounded-full border border-ink/15">
                        <button onClick={() => onSetQty(Math.max(1, qty - 1))} className="grid h-8 w-8 place-items-center text-ink transition hover:text-rose-deep" aria-label="Decrease quantity">−</button>
                        <span className="w-6 text-center text-sm font-semibold text-ink">{qty}</span>
                        <button onClick={() => onSetQty(Math.min(10, qty + 1))} className="grid h-8 w-8 place-items-center text-ink transition hover:text-rose-deep" aria-label="Increase quantity">+</button>
                      </div>
                      <span className="font-display text-sm font-semibold text-ink">{formatAUD(qty * PRODUCT.price)}</span>
                    </div>
                  </div>
                </div>
                <button onClick={() => onSetQty(0)} className="mt-3 text-xs text-ink/40 underline-offset-2 hover:underline">
                  Remove from bag
                </button>
              </>
            )
          )}

          {stage === 'checkout' && (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-sm leading-relaxed text-ink/60">
                Ships Australia-wide. You’ll get a confirmation at the email below.
              </p>
              <div>
                <label className="font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/60">Full name</label>
                <input required name="name" placeholder="Sonia Tomas" className="mt-1.5 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm text-ink outline-none transition focus:border-rose" />
              </div>
              <div>
                <label className="font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/60">Email</label>
                <input required type="email" name="email" placeholder="you@yoursalon.com.au" className="mt-1.5 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm text-ink outline-none transition focus:border-rose" />
              </div>
              <div>
                <label className="font-display text-[10px] font-semibold uppercase tracking-[0.18em] text-ink/60">Salon &amp; delivery address</label>
                <textarea required name="address" rows={3} placeholder="Salon name, street, suburb, state, postcode" className="mt-1.5 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm text-ink outline-none transition focus:border-rose" />
              </div>
              <div className="flex items-center justify-between rounded-2xl bg-sand/50 px-5 py-4">
                <span className="text-sm text-ink/70">{qty} × deck</span>
                <span className="font-display text-lg font-semibold text-ink">{formatAUD(total)}</span>
              </div>
              <button type="submit" className="w-full rounded-full bg-rose-deep py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-cream transition hover:bg-ink">
                Place order — {formatAUD(total)}
              </button>
              <p className="text-center text-[11px] leading-relaxed text-ink/40">
                You’ll be contacted to confirm payment and delivery. No card is charged on this page.
              </p>
              <button type="button" onClick={() => setStage('bag')} className="w-full text-center text-xs text-ink/50 underline-offset-2 hover:underline">
                ← Back to bag
              </button>
            </form>
          )}

          {stage === 'done' && order && (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <span className="grid h-14 w-14 place-items-center rounded-full bg-rose/20 text-2xl">✓</span>
              <h3 className="mt-5 font-display text-xl font-semibold text-ink">Your deck is confirmed.</h3>
              <p className="mt-3 text-sm leading-relaxed text-ink/60">
                Thanks {order.name.split(' ')[0] || 'legend'} — order <span className="font-semibold text-ink">{order.id}</span> is on its way to your inbox at {order.email}.
              </p>
              <p className="mt-3 text-sm leading-relaxed text-ink/60">
                Most decks arrive in 5–8 business days. Put it on the back bar the morning it lands.
              </p>
              <button onClick={close} className="mt-7 rounded-full bg-rose-deep px-7 py-3 font-display text-xs font-semibold uppercase tracking-[0.15em] text-cream transition hover:bg-ink">
                Done
              </button>
            </div>
          )}
        </div>

        {stage === 'bag' && qty > 0 && (
          <footer className="border-t border-sand px-6 py-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-ink/60">Subtotal</span>
              <span className="font-display text-lg font-semibold text-ink">{formatAUD(total)}</span>
            </div>
            <p className="mt-1 text-xs text-ink/40">Complimentary shipping across Australia.</p>
            <button onClick={() => setStage('checkout')} className="mt-4 w-full rounded-full bg-rose-deep py-4 font-display text-xs font-semibold uppercase tracking-[0.18em] text-cream transition hover:bg-ink">
              Checkout
            </button>
          </footer>
        )}
      </aside>
    </div>
  );
}
