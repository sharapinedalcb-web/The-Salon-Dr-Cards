
export const PRODUCT = {
  id: '30-days-retail-confidence',
  name: '30 Days to Retail Confidence',
  price: 74.44,
  tagline: 'The daily card deck for the salon floor.',
  blurb:
    'One card. Five minutes. Every morning, before the first client sits down. The Daily Huddle, in their hands — so retail confidence doesn’t depend on you reminding anyone.',
};

/** What's physically inside the box. */
export const DECK_CONTENTS = [
  { count: '30', label: 'Retail Confidence Cards' },
  { count: '25', label: 'Mindset Cards' },
];

// The morning photo is loaded from public/images/morning-photo.jpg when that file exists.
// Until then the page shows a fallback; the on-page selector is a local preview only.
export const HERO_PHOTO_URL = ''; // deck fanned in hands
export const MORNING_PHOTO_URL = '/images/morning-photo.jpg';

/** The three cards featured on the page — real deck content. */
export const SAMPLE_CARDS = [
  {
    id: 'tailor',
    name: 'Tailored Recommendations',
    quote: 'Would it be okay for me to tailor my recommendations based on what you’ve shared today.',
    back: [
      { heading: 'Why it matters:', body: 'Personalisation increases trust and conversion.' },
      { heading: 'Salon Dr Tip', body: 'Recommend → Educate → Plan → Rebook → Thank' },
      { heading: 'Opportunity', body: 'Confident close with tailored plan + next steps' },
    ],
  },
  {
    id: 'question',
    name: 'One Good Question',
    quote: 'What’s One Question You Could Ask Instead of Assuming?',
    back: [
      { heading: 'Curiosity creates connection.', body: 'Assumptions remove choice.' },
    ],
  },
  {
    id: 'repeatable',
    name: 'Success Is Repeatable',
    quote: 'Success Is Repeatable When Behaviour Is Identified.',
    back: [
      { heading: 'Name the behaviour:', body: 'What exactly did you do that worked?' },
      { heading: 'Salon Dr Tip', body: 'Repeat it → Refine it → Make it routine' },
      { heading: 'Opportunity', body: 'Confidence built on evidence, not luck' },
    ],
  },
];

export const MORNING_STEPS = [
  {
    time: '8:45',
    title: 'Pull today’s card',
    text: 'Whoever opens the salon takes the top card off the deck on the back bar. No prep, no laptop, no slides.',
  },
  {
    time: '8:47',
    title: 'Read the prompt out loud',
    text: 'The front names the ritual. The back is what your team actually says out loud — everyone answers, nobody hides.',
  },
  {
    time: '8:50',
    title: 'Set the day’s commitment',
    text: 'Each stylist names one retail or consultation commitment for the day. Said out loud, it tends to happen.',
  },
  {
    time: '8:50+',
    title: 'Open the doors',
    text: 'Five minutes, done. The team walks to their chairs focused, aligned and ready to recommend with confidence.',
  },
];

export const INCLUDES = [
  { icon: 'cards', title: '30 Retail Confidence Cards', text: 'A month of real consultation and recommendation prompts your team can use chair-side the same morning.' },
  { icon: 'mindset', title: '25 Mindset Cards', text: 'The belief work behind the selling — why your team resists recommending, and how to replace that story.' },
  { icon: 'box', title: 'Back-bar display box', text: 'A keepsake box that lives on the back bar, so the ritual is impossible to forget.' },
  { icon: 'repeat', title: 'Restart-proof', text: 'Finished the 30 days? Shuffle and go again. The prompts are built to be repeated.' },
];

/** Formats AUD, showing cents only when the amount isn't a whole number. */
export const formatAUD = (n: number) =>
  Number.isInteger(n)
    ? n.toLocaleString('en-AU', { style: 'currency', currency: 'AUD', maximumFractionDigits: 0 })
    : n.toLocaleString('en-AU', { style: 'currency', currency: 'AUD', minimumFractionDigits: 2 });
